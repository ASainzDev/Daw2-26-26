package com.gestion.pistas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PistasApplication {

	public static void main(String[] args) {
		SpringApplication.run(PistasApplication.class, args);
	}

}
