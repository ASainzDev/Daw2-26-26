package com.example.minitienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinitiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
