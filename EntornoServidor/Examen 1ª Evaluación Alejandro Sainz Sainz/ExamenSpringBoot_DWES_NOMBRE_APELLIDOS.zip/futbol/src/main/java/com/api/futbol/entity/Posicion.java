

package com.api.futbol.entity;


public enum Posicion {

    PORTERO,DEFENSE,MEDIO,DELANTERO;
}
