package com.example.football_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FootballAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FootballAppApplication.class, args);
	}

}
