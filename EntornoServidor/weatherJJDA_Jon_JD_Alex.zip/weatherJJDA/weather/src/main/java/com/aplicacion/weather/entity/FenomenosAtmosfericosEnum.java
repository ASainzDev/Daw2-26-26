
package com.aplicacion.weather.entity;

public enum FenomenosAtmosfericosEnum {

    SECO, SOLEADO, LLUVIOSO, TORMENTOSO, NIEVE, GRANIZOS;

}
