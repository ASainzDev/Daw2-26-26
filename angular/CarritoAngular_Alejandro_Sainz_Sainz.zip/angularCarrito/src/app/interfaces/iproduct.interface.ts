export interface IProduct {

    sku: string,
    title: string,
    price: string
}
