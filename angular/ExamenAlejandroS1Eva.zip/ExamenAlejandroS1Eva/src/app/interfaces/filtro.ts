export interface Filtro {
    "name": string,
    "price": number,
    "category": string,
    "active": boolean,
}
