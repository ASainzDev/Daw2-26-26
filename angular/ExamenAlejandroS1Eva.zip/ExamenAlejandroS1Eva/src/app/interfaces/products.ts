// Defino una interface que se adecue a la entity que tenemos en el back

export interface Products {
     "id" : string,
     "name" : string,
     "description" :string,
     "price" : number,
     "category" : string,
     "image" : string,
     "active" : boolean,
}
