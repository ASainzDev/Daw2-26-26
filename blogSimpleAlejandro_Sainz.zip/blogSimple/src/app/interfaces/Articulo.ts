export interface Articulo {

     
        id : number,
        titulo : string,
        url : string,
        contenido : string,
        fecha: string,        
    
}
